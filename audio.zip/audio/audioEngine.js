class AudioEngine {
  constructor() {
    this.ctx = null
    this.source = null
    this.preamp = null
    this.eqBands = []
    this.masterGain = null

    this.currentBuffer = null
    this.isPlaying = false
    this.startTime = 0
    this.pauseTime = 0
  }

  async init() {
    if (this.ctx) return

    this.ctx = new (window.AudioContext || window.webkitAudioContext)()

    this.preamp = this.ctx.createGain()
    this.preamp.gain.value = 1

    const freqs = [32,64,125,250,500,1000,2000,4000,8000,16000]
    let prev = this.preamp

    freqs.forEach(freq => {
      const f = this.ctx.createBiquadFilter()
      f.type = "peaking"
      f.frequency.value = freq
      f.Q.value = 1
      f.gain.value = 0
      prev.connect(f)
      prev = f
      this.eqBands.push(f)
    })

    this.masterGain = this.ctx.createGain()
    this.masterGain.gain.value = 1

    prev.connect(this.masterGain)
    this.masterGain.connect(this.ctx.destination)
  }

  async loadArrayBuffer(buffer) {
    await this.init()
    this.currentBuffer = await this.ctx.decodeAudioData(buffer)
  }

  play(offset = 0) {
    if (!this.currentBuffer) return
    this.stop()

    this.source = this.ctx.createBufferSource()
    this.source.buffer = this.currentBuffer
    this.source.connect(this.preamp)

    this.startTime = this.ctx.currentTime - offset
    this.source.start(0, offset)
    this.isPlaying = true

    this.source.onended = () => {
      this.isPlaying = false
      this.pauseTime = 0
    }
  }

  pause() {
    if (!this.isPlaying) return
    this.pauseTime = this.ctx.currentTime - this.startTime
    this.stop()
  }

  resume() {
    if (this.pauseTime != null) this.play(this.pauseTime)
  }

  stop() {
    if (this.source) {
      this.source.stop()
      this.source.disconnect()
      this.source = null
    }
    this.isPlaying = false
  }

  setEQ(i, gain) {
    const band = this.eqBands[i]
    if (!band) return
    const now = this.ctx.currentTime
    band.gain.cancelScheduledValues(now)
    band.gain.linearRampToValueAtTime(gain, now + 0.15)
  }

  setMasterVolume(v) {
    this.masterGain.gain.value = v
  }
}

export default new AudioEngine()
